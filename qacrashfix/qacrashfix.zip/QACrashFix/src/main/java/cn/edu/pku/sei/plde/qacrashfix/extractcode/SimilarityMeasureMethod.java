package cn.edu.pku.sei.plde.qacrashfix.extractcode;

public enum SimilarityMeasureMethod {
	SimilarityMeasureByCommonWords, SimilarityMeasureByEditDistance;
}
