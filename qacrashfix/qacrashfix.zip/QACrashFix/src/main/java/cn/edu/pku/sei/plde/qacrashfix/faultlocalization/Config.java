package cn.edu.pku.sei.plde.qacrashfix.faultlocalization;

public class Config {
	
    public static int linesize = 8;
    public static double threshold_of_edit_distance = 0.126;
    public static double threshold_of_structure_distance = 0.67;
}
